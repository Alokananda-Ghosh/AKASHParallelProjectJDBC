package com.cg.Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;





public class BankDaoImpl implements IBankDao {
	
	private Connection con=null;
	private PreparedStatement ps=null;
	
	public void getConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");//Step 1
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		String user="system";
		String pass="Capgemini123";
		
		con=DriverManager.getConnection(url, user, pass);
	}
	
	public void putdata(String name,long contact,String mail,double balance) throws ClassNotFoundException, SQLException
	{
		getConnection();
		ps=con.prepareStatement("insert into Bank values(pid_seq.nextval,?,?,?,?)");
	
		ps.setString(1,name);
		ps.setLong(2, contact);
		ps.setDouble(3, balance);
		ps.setString(4, mail);
		ps.executeUpdate();
		
		ps=con.prepareStatement("select * from Bank where name=?");
		ps.setString(1, name);
		ResultSet rs=ps.executeQuery();
		rs.next();
		int id=rs.getInt(1);
		
		System.out.println("\nYour Account is created and your account id is "+ id +"\n");
		
		con.close();
	}
	
	public void showdetails() throws ClassNotFoundException, SQLException
	{
		getConnection();
		ps=con.prepareStatement("select * from Bank");
		ResultSet rs=ps.executeQuery();
		
		System.out.println("\nAll account details --------- \n");
		while(rs.next()) 
		{
			System.out.print(rs.getInt(1)+" ");
			System.out.print(rs.getString(2)+" ");
			System.out.print(rs.getLong(3)+" ");
			System.out.print(rs.getDouble(4)+" ");
			System.out.println(rs.getString(5));
		}
		System.out.println();
		con.close();
	}
	
	public void withdraw(int AccNo,double bal) throws SQLException, ClassNotFoundException
	{
		getConnection();
		ps=con.prepareStatement("select * from Bank where AccNo=?");
		ps.setInt(1, AccNo);
		ResultSet rs=ps.executeQuery();
		rs.next();
		String name=rs.getString(2);
		double CBal=rs.getDouble(4);

		if(CBal>bal)
		{
			double temp=CBal-bal;
			if(temp>500)
			{
			
				ps=con.prepareStatement("update Bank set balance=? where AccNo=?");
				ps.setDouble(1,temp);
				ps.setInt(2, AccNo);
				ps.executeUpdate();
				
				ps=con.prepareStatement("insert into BankTransaction values(?,?,?,?)");
				ps.setInt(1,AccNo);
				String details=name+" withdraw "+bal+" on ";
				ps.setString(2,details);
				ps.setDate(3, Date.valueOf(LocalDate.now()));
				String t=LocalTime.now()+"";
				ps.setString(4, t);
				ps.executeUpdate();
				
				System.out.println("\nWithdraw Completed \n");
				
			}
			else
			{
				System.out.println("\nSorry you do not have enough balance\n");
			}
				
		}
		else
			System.out.println("\nSorry you do not have enough balance\n");
		con.close();
	}
	
	public void deposit(int AccNo,double bal) throws ClassNotFoundException, SQLException
	{
		getConnection();
		ps=con.prepareStatement("select * from Bank where AccNo=?");
		ps.setInt(1, AccNo);
		ResultSet rs=ps.executeQuery();
		rs.next();
		String name=rs.getString(2);
		double CBal=rs.getDouble(4);
		double temp=CBal+bal;
		if(temp>=1000000)
		{
			System.out.println("\nSorry we could not proceed you reached max limit of 1000000 \n");
		}
		else
		{
			ps=con.prepareStatement("update Bank set balance=? where AccNo=?");
			ps.setDouble(1,temp);
			ps.setInt(2, AccNo);
			ps.executeUpdate();
		
			ps=con.prepareStatement("insert into BankTransaction values(?,?,?,?)");
			ps.setInt(1,AccNo);
			String details=name+" deposit "+bal+" on ";
			ps.setString(2,details);
			ps.setDate(3, Date.valueOf(LocalDate.now()));
			String t=LocalTime.now()+"";
			ps.setString(4, t);
			ps.executeUpdate();
			System.out.println("\nDeposit Completed \n");
			
		}
		con.close();
	}
	public void search(String name2) throws ClassNotFoundException, SQLException
	{
		getConnection();
		ps=con.prepareStatement("select * from Bank where name=?");
		ps.setString(1, name2);
		ResultSet rs=ps.executeQuery();
		rs.next();
		System.out.println(name2+" remaining balance "+ rs.getDouble(4));
		
	}
	
	public void transaction(int id1,int id2,double amt) throws ClassNotFoundException, SQLException
	{
		getConnection();
		ps=con.prepareStatement("select * from Bank where AccNo=?");
		ps.setInt(1,id1);
		ResultSet rs=ps.executeQuery();
		rs.next();
		String name1=rs.getString(2);
		double CBal=rs.getDouble(4);
		if(CBal>amt)
		{
			double temp=CBal-amt;
			if(temp>500)
			{
				getConnection();
				ps=con.prepareStatement("select * from Bank where AccNo=?");
				ps.setInt(1,id2);
				ResultSet rs2=ps.executeQuery();
				rs2.next();
				String name2=rs2.getString(2);
				double CBal2=rs2.getDouble(4)+amt;
				if(CBal2>=1000000)
				{
					System.out.println("\nSorry we could not proceed you reached max limit of 1000000\n");
				}
				else
				{
					ps=con.prepareStatement("update Bank set balance=? where AccNo=?");
					ps.setDouble(1,CBal2);
					ps.setInt(2, id2);
					ps.executeUpdate();
					
					ps=con.prepareStatement("insert into BankTransaction values(?,?,?,?)");
					ps.setInt(1,id1);
					String details=name1+" Transfered "+amt+" to "+name2;
					ps.setString(2,details);
					ps.setDate(3, Date.valueOf(LocalDate.now()));
					String t=LocalTime.now()+"";
					ps.setString(4, t);
					ps.executeUpdate();
					
					ps=con.prepareStatement("update Bank set balance=? where AccNo=?");
					ps.setDouble(1,temp);
					ps.setInt(2, id1);
					ps.executeUpdate();
					
					
					ps=con.prepareStatement("insert into BankTransaction values(?,?,?,?)");
					ps.setInt(1,id2);
					String details2=name1+" Transfered "+amt+" to "+name2;
					ps.setString(2,details2);
					ps.setDate(3, Date.valueOf(LocalDate.now()));
					String t1=LocalTime.now()+"";
					ps.setString(4, t1);
					ps.executeUpdate();
					
					System.out.println("\nTransfer Completed \n");
			
				}
			}
			else
			{
				System.out.println("sorry you do not have enough balance");
			}
				
		}
		else
			System.out.println("sorry you do not have enough balance");
		con.close();
		
	}
	public void printTransaction(int AccNo) throws ClassNotFoundException, SQLException
	{
		getConnection();
		ps=con.prepareStatement("select * from BankTransaction where AccNo=?");
		ps.setInt(1,AccNo);
		ResultSet rs=ps.executeQuery();
		System.out.println("\n Your all previous transactions ----- \n ");
		while(rs.next())
		{
			System.out.print(rs.getInt(1)+" ");
			System.out.print(rs.getString(2)+" ");
			System.out.print(rs.getDate(3)+" ");
			System.out.println(rs.getString(4));
		}
		
	}
}