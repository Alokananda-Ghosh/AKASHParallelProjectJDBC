package com.cg.Dao;

import java.sql.SQLException;
import java.time.LocalDate;

public interface IBankDao {
	
	public void putdata(String name,long contact,String mail,double balance) throws ClassNotFoundException, SQLException;
	public void showdetails() throws ClassNotFoundException, SQLException;
	public void withdraw(int AccNo,double bal) throws SQLException, ClassNotFoundException;
	public void deposit(int AccNo,double bal) throws ClassNotFoundException, SQLException;
	
	public void search(String name2) throws ClassNotFoundException, SQLException;
	
	public void transaction(int id1,int id2,double amt) throws ClassNotFoundException, SQLException;

	public void printTransaction(int AccNo) throws ClassNotFoundException, SQLException;


}
