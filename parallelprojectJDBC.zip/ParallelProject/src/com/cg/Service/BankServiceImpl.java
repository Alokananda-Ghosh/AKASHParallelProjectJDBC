package com.cg.Service;

import java.sql.SQLException;
import java.time.LocalDate;

import com.cg.Dao.BankDaoImpl;



public class BankServiceImpl implements IBankService{
	BankDaoImpl ob=new BankDaoImpl();
	@Override
	public void putdata( String name, long contact,String mail,double balance) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		ob.putdata( name, contact,mail, balance);
	}

	@Override
	public void showdetails() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		ob.showdetails();
	}

	@Override
	public void withdraw(int AccNo, double bal) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		ob.withdraw(AccNo,bal);
	}
	public void deposit(int AccNo, double bal) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		ob.deposit(AccNo,bal);
	}
	
	
	public void search(String name2) throws ClassNotFoundException, SQLException
	{
		ob.search(name2);
	}
	
	public void transaction(int id1,int id2,double amt) throws ClassNotFoundException, SQLException
	{
		ob.transaction(id1,id2,amt);
	}
	
	public void printTransaction(int AccNo) throws ClassNotFoundException, SQLException
	{
		ob.printTransaction(AccNo);
	}

}
