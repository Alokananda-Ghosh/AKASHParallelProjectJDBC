package com.cg.Ui;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Random;
import java.util.Scanner;

import com.cg.Service.BankServiceImpl;



public class XYZBank
{
 public static void main(String[] args) throws ClassNotFoundException, SQLException 
 	{
	 	Scanner sc=new Scanner(System.in);
	 	BankServiceImpl ob=new BankServiceImpl();
	 	Random rd=new Random();
	 	
	 	char s;
	 	do
	 	{
	 		System.out.println("press 1 to create account\n 2 to show details of all account\n 3 to withdraw \n 4 to deposit \n 5 to transfer money \n 6 to search any account balance \n 7 to print all transaction \n 8 to exit");
	 		int n=sc.nextInt();
	 		switch(n)
	 		{
	 		case 1:
	 				System.out.println("enter Name, Contact no, the Opening Amount to open account and mailid");
	 				String name=sc.next();
	 				long contact=sc.nextLong();
	 				String contact2=contact+"";
	 				String regEx="(91|0)?[6-9][0-9]{9}";
	 				while(!(contact2.matches(regEx)))
	 				{
	 					System.out.println("enter contact again");
	 					contact=sc.nextLong();
	 					contact2=contact+"";
	 				}
	 				double balance=sc.nextDouble();
	 				
	 				try{
	 					if(balance<=500)
	 			
	 					{
	 						throw new MinBalExp("min 500 bal is required");
	 					}
	 				
	 				}
	 				catch(MinBalExp e)
	 				{
	 					System.out.println(e);
	 					System.out.println("enter balance again but >500");
	 					balance=sc.nextDouble();
	 					while(balance<500)
	 					{
	 						System.out.println("enter balance again but >500");
		 					balance=sc.nextDouble();
	 					}

	 				}
	 				String mail=sc.next();
	 				String regEx2="[a-zA-Z0-9]+[@][a-zA-Z0-9]+([.][a-zA-Z]{2,})+";
	 				while(!(mail.matches(regEx2)))
	 				{
	 					System.out.println("enter mail again");
	 					mail=sc.next();
	 				}
	 				
	 			/*	int AccNo=rd.nextInt(10000000);
	 				String AccNoStr=AccNo+"";
	 				String regEx3="[0-9]{6,6}";
	 				while(!(AccNoStr.matches(regEx3)))
	 				{
	 					
	 					AccNo=rd.nextInt(10000000);
	 					AccNoStr=AccNo+"";
	 				}	 
	 				
	 			*/
	 				ob.putdata(name, contact,mail, balance);
	 				break;
	 		case 2:
	 				ob.showdetails();
	 				break;
	 		case 3:
	 				ob.showdetails();
	 				System.out.println("enter your AccNo");
	 				int AccNo2=sc.nextInt();
	 				System.out.println("enter balance to withdraw");
	 				double bal=sc.nextDouble();
	 				ob.withdraw(AccNo2,bal);
	 				break;
	 		case 4:
	 				ob.showdetails();
	 				System.out.println("enter your AccNo");
	 				int AccNo3=sc.nextInt();
	 				System.out.println("enter balance to deposit");
	 				double bal3=sc.nextDouble();
 					ob.deposit(AccNo3,bal3);
 					break;
	 		case 5:
	 				ob.showdetails();
	 				System.out.println("enter your accNo and the accNo you want to transfer");
	 				int id1=sc.nextInt();
	 				int id2=sc.nextInt();
	 				System.out.println("enter amount to transfer");
	 				double amt=sc.nextDouble();
	 				ob.transaction(id1,id2,amt);
	 				break;
	 		case 6:
	 				System.out.println("enter name to search");
	 				String name2=sc.next();
	 				ob.search(name2);
	 				break;
	 				
	 		case 7:
	 			
	 			
	 				ob.showdetails();
	 				System.out.println("enter the accNo you want to see all transaction details");
	 				int AccNo4=sc.nextInt();
	 				ob.printTransaction(AccNo4);
	 				break;
	 			
	 			
	 		case 8:
	 				System.exit(1);
	 				break;
	 		default:
	 				System.out.println("wrong input");
	 				
	 		}
	 	
	 	}while(true);
 	}
}
