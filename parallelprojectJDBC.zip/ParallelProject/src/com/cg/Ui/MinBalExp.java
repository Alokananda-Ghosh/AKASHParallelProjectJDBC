package com.cg.Ui;



public class MinBalExp extends Exception {
	
	MinBalExp(String msg)
	{
		super(msg);
	}

}